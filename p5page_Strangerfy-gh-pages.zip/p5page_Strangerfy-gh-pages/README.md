# Strangerfy試してみた

## これは何？

Strangerfyを使ったサンプルページを作成しました。  
Strangerfyのgithubページは以下です。  
[GitHub \- lee2sman/Strangerfy: Framework for quickly creating any website along with built\-in P5JS template](https://github.com/lee2sman/Strangerfy)

お試しレポート記事を書きました。  
[Strangerfy(と、GitHub Pages)でp5.jsスケッチを背景にしたWebページをさくっと作る : だらっと学習帳](http://blog.livedoor.jp/reona396/archives/55672718.html)

## p5.js スケッチについて

以下のProcessing.jsスケッチをp5.jsに書き直し、一部アレンジしました。  
[Polka_Dots_Random_Walkers - OpenProcessing](https://www.openprocessing.org/sketch/310924)

## つくった人

[reona396](http://reona396.information.jp/)
